<script>
 $('html, body').animate({
            scrollTop: $("#main").offset().top
        }, 0);
</script>