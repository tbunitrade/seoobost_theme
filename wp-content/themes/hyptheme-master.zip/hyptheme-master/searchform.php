<form action="<?php bloginfo('siteurl'); ?>" id="searchform" method="get">


        <input placeholder="Что ищем?" type="text" id="s" name="s" value="" />



</form>