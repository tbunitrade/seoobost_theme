<?php get_header(); ?>
<section class="p404">
    <h1 class="text404">404</h1>

</section>